# pokerbot
gives the best poker hand out of random cards
